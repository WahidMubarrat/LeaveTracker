export default function LeaveCard({ leave }) {
  const getStatusClass = () => {
    if (leave.status === "Approved") return "approved";
    if (leave.status === "Declined") return "rejected";
    return "pending";
  };

  return (
    <div className={`leave-card ${getStatusClass()}`}>
      <div className="leave-card-header">
        <h3>{leave.type?.toUpperCase()} Leave</h3>
        <span className={`badge ${getStatusClass()}`}>
          {leave.status}
        </span>
      </div>

      <div className="leave-info">
        <p>📅 {leave.startDate} → {leave.endDate}</p>
        <p>⏳ {leave.numberOfDays} Days</p>
        <p>
          {leave.approvedByHR
            ? "✅ Approved by HR"
            : leave.approvedByHoD
            ? "⏳ Waiting for HR"
            : "⏳ Waiting for HoD"}
        </p>
      </div>
    </div>
  );
}
